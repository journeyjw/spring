package com.mybatis3.deep;

public class AddressDao {
	
}
