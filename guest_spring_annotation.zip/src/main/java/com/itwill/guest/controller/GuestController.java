package com.itwill.guest.controller;

import org.springframework.stereotype.Controller;

@Controller
public class GuestController {
	
}
