package com.itwill.annotation;

public class MyFieldAnnotationUsing {
	@MyFieldAnnotation(name = "someName", value = "Hello World")
	public String myField = null;
}