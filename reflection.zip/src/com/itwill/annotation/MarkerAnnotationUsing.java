package com.itwill.annotation;
@MakerAnnotation
public class MarkerAnnotationUsing {

}